package com.test.bostweb // Замените com.yourpackage на ваш пакет

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class WebViewActivity : AppCompatActivity() {

    @SuppressLint("SetJavaScriptEnabled") // JavaScript нужен для многих современных сайтов
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web_view)

        val webView: WebView = findViewById(R.id.webView)
        webView.webViewClient = WebViewClient() // Чтобы ссылки открывались в WebView, а не в браузере
        webView.settings.javaScriptEnabled = true // Включаем JavaScript

        // Загружаем URL
        webView.loadUrl("https://boosty.to/")

        // Опционально: обработка кнопки "назад" для навигации в WebView
        webView.canGoBack()
        webView.setOnKeyListener { _, keyCode, _ ->
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
                webView.goBack()
                return@setOnKeyListener true
            }
            false
        }
    }

    // Убедитесь, что при нажатии кнопки "назад" на устройстве,
    // если WebView может вернуться назад, он это делает.
    override fun onBackPressed() {
        val webView: WebView = findViewById(R.id.webView)
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}